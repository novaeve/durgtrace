---
name: molclaw-compound-retrieve
description: Retrieve SMILES strings by compound name using PubChem with an NCI resolver fallback.
license: MIT license
metadata:
    skill-author: PJLab
---

# Retrieve Compound SMILES

Note: 
- Local files are not directly accessible by the server. Please upload them to the server using `molclaw-file-transfer` before execution. 
- For PDB file inputs, it is recommended to preprocess them using `molclaw-pdbfixer` before execution.
- Please refer to skill `molclaw-scp-server` to complete tool invocation.

The description of tool *retrieve_smiles_by_compoundname*.

```tex
Retrieve SMILES strings by compound name. The service queries PubChem first and falls back to the NCI resolver when PubChem is busy or unavailable.
Args:
    compound_names (List[str]): List of input compound names (e.g., ["aspirin", "caffeine"])
Return:
    status (str): success/partial_success/error
    msg (str): message
    retrieve_smiles (List[dict]): List of dict, each containing the keys 'compound_name' and 'smiles'.
        --compound_name (str): A compound name of compound_names 
        --smiles (str): The retrieved SMILES string, if it exists; otherwise, None.
```

How to use tool *retrieve_smiles_by_compoundname* :

```python
response = await client.session.call_tool(
    "retrieve_smiles_by_compoundname",
    arguments={
        "compound_names": compound_names
    }
)
result = client.parse_result(response)
retrieve_smiles = result["retrieve_smiles"]
```
