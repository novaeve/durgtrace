# Release index: sol_pi_logp_qed_s2_common_eval_20261008

This directory is a frozen experiment source snapshot. Original README files describe historical deployments; follow the release-level documentation for scope and current verification.

Group: `appendix`. See [reproduction](../../../docs/reproduction.md) and [paper mapping](../../../docs/paper_map.md).

## Located entrypoints

- `rescore.py` — see its module entry block / calling driver.
